/*
$('#plano_saude').autocomplete({
    source: function (request, response) {
        $.getJSON("./plano_saude.json?term=" + request.term, function (data) {
            response($.map(data.planos, function (value, key) {
                return {
                    label: value,
                    value: key
                };
            }));
        });
    },
    minLength: 2,
    delay: 100
});
*/

/*
$("#plano_saude").autocomplete({
    source: function(request, response) {
        $.getJSON("js/plano_saude.json?term=" + request.term, function(data){
            response($.map(data.planos, function(value, key){
                return {
                    label:value,
                    value:key
                };
            }));
        });
    },
    minLength:2,
    delay:100
});
*/
var planos = [ "Ameplan (Assistência Médica Planejada)",
      "Alice",
      "Allianz",
      "Amil - DIX - Medial - One Health",
      "Assim Saúde",
      "BioVida",
      "Bradesco",
      "Care Plus",
      "CCG - centro clínico gaúcho",
      "Clinipam",
      "E-vida",
      "Golden Cross - Vision Med",
      "GreenLine",
      "Hapvida - São Francisco",
      "Ipasgo",
      "NotreDame Intermédica",
      "Omint",
      "Porto Seguros - Itaú Saúde",
      "Prevent Senior",
      "Pró Médica",
      "Sami",
      "Saúde Caixa - Caixa Seguros - Rede Gama",
      "Saúde Sim",
      "Sompo Saúde - Marítima",
      "SulAmérica",
      "Trasmontano",
      "Unimed",
      "CNU (Central Nacional Unimed)",
      "Seguros Unimed",
      "Qsaúde",
      "Vitallis",
      "NA (Não Aplicável)"];


$("#plano_saude").autocomplete({
    source:planos,
    minLength:2,
    delay:100
});


$("#plano_saude").blur(function(){
    $("#resposta_q1").html("");
    $("#resposta_q1").html($("#plano_saude").val());
});


var count = 0;

var malInformado = (valor) => {


    for ( var i = 0; i < 6; i++ ) {
        $("#mal_informado_"+i).prop('checked', false);
        $("#mal_informado_"+i).prop('disabled', false);
    }


    if ( valor == 4 || valor == 5 ) {
        $("#mal_informado_razao").show('slow');
        count = 0;
    } else {
        $("#mal_informado_razao").hide('slow');
        count = 0;
    }
};


var malInformadoRazao = (obj) => {


    var checado = $(obj).is(':checked');

    // alert(checado+", count="+count);

    if ( checado ) {
        count++;
    } else {
        count--;
    }

 

    if ( count > 3 ) {
        alert("Escolha apenas 3 opções");
        $(obj).prop('checked', false);
        count--;
    }


};


$("#mal_informado_5").click(function(){
    if ( $("#mal_informado_5").is(":checked") ) {

        count = 0;

        for (var l = 0; l < 5; l++) {
            $("#mal_informado_"+l).prop('checked', false);
            $("#mal_informado_"+l).prop('disabled', true);
        }
    } else {

        count = 0;

        for (var m = 0; m < 5; m++) {
            $("#mal_informado_"+m).prop('checked', false);
            $("#mal_informado_"+m).prop('disabled', false);
        }
    }
});


var correntistaConfirm = (valor) => {
    if ( valor == 1 ) {
        for ( var w = 0; w < 10; w++ ) {
            $("#produtos_7_"+w).prop('checked', false);
        }
        $("#produto_outro_nc").val("");
        $("#sete_um").hide("slow");
        $("#interesse_conta_sim").prop('checked', false);
        $("#interesse_conta_nao").prop('checked', false);
        $("#q7").hide('slow');
        $("#q8").hide('slow');
        $("#q6").show('slow');

    }

    if ( valor == 0 ) {
        for ( var h = 0; h < 10 ; h++ ) {
            $("#produtos_"+h).prop('checked', false);
        }
        $("#produto_outro").val("");
        $("#seis_um").hide('slow');
        $("#q6").hide('slow');
        $("#q7").show('slow');
        $("#q8").show('slow');

    }
};


var produtoInserir = (obj) => {

    var checadoProduto = $(obj).is(':checked');

    if ( checadoProduto ) {
        $("#produto_outro").val("");
        $("#seis_um").show('slow');

    } else {
        $("#produto_outro").val("");
        $("#seis_um").hide('slow');
    }
};

var produtoInserirSete = (obj) => {

    var checadoProduto7 = $(obj).is(':checked');

    if ( checadoProduto7 ) {
        $("#produto_outro_nc").val("");
        $("#sete_um").show('slow');

    } else {
        $("#produto_outro_nc").val("");
        $("#sete_um").hide('slow');
    }
};


var darNota = (valor) => {
    if ( valor != 9 && valor != 10 ) {
        $("#nota_motivo").val("");
        $("#nove_um").show('slow');
    } else {
        $("#nota_motivo").val("");
        $("#nove_um").hide('slow');
    }
};


var somente_numeros = (e) => {
    
    var nav4 = window.Event ? true : false;
    
    if(nav4) {
        var whichCode = e.which;
    } else {
        var whichCode = e.keyCode;
    }

    if (whichCode > 47 && whichCode < 58 || whichCode == 8 || whichCode ==9 || whichCode == 0) {
        return true;
    } else {    
        return false;
    }
};


$("#tempo_meses").keyup(function(){
    var meses = $("#tempo_meses").val();

    if ( meses > 11 || meses < 1) {
        alert('Mês inválido, ou maior que 12 !!!');
        $("#tempo_meses").val("");
    }
});