var confirmar = () => {
	window.location = 'form.html';
}